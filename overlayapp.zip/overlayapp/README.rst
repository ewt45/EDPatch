VirGL Overlay is used with Mesa to get GPU acceleration, typically in Exagear Windows Emulator for Android.
Application based on Mittorn port of virglrenderer for Android:
https://github.com/mittorn/virglrenderer
https://github.com/mittorn/virglrenderer-android

Also the following code was used in this repository:

virglrenderer https://github.com/freedesktop/virglrenderer
libepoxy https://github.com/anholt/libepoxy
gl4es https://github.com/ptitSeb/gl4es


