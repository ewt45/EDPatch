#!/bin/bash

. /opt/recipe/util/progress.sh

if [ "$(locale -a | grep $LC_ALL)" != "$LC_ALL" ]; then
    progress "-1" "Generating locale..."
    locale-gen --no-archive $LC_ALL
fi

progress "-1" "Launching application..."
export PATH
export TERM
export LD_PRELOAD=/opt/recipe/run/hardlink_to_symlink.so
/opt/recipe/run/sshd &

ed=/storage/emulated/0/Exagear/ed
virgl=/opt/virgl

if [ ! -f $ed/ed.conf ]; then
mkdir -p $ed
cp /opt/recipe/ed.conf $ed/ed.conf
fi

if [ ! -f $virgl/hack_settings ]; then
mkdir -p $virgl
cp /opt/recipe/hack_settings $virgl/hack_settings
fi

. $ed/ed.conf



if [ "${pulse}" = "1" ]; then
export PULSE_SERVER="tcp:127.0.0.1:4713"
fi

if [ "${hud}" = "1" ]; then
export GALLIUM_HUD="simple,fps"
fi

if [ "${dxtn}" = "0" ]; then
cp /opt/recipe/hack_settings $virgl/hack_settings
fi

if [ "${dxtn}" = "1" ]; then
cp /opt/recipe/hack_settings_dxtn $virgl/hack_settings
fi

progress "-1" "Pulse=${pulse}/Hud=${hud}/DXTn=${dxtn}"

eval "$@"
