#!/bin/bash

. /opt/recipe/util/progress.sh

if [ "$(locale -a | grep $LC_ALL)" != "$LC_ALL" ]; then
    progress "-1" "Generating locale..."
    locale-gen --no-archive $LC_ALL
fi

progress "-1" "Launching application..."

if ls "/opt/Driver/pulseaudio_installed.lnk" &>/dev/null
then
    cp "/opt/Driver/dsound.dll.404" "/opt/wine-stable/lib/wine/dsound.dll.so"
    cp "/opt/Driver/dsound.dll.504" "/opt/wine-5.0.4/lib/wine/dsound.dll"
    cp "/opt/Driver/dsound.dll.604" "/opt/wine-6.0.4/lib/wine/dsound.dll"
    rm "/opt/wine-5.0.4/lib/wine/dsound.dll.so" &>/dev/null
    rm "/opt/wine-6.0.4/lib/wine/dsound.dll.so" &>/dev/null
    unset AXS_DSOUND_SERVER_PORT
    export PULSE_SERVER="tcp:127.0.0.1:4713"
else 
    cp "/opt/Driver/eltechs_dsound.dll.so" "/opt/wine-stable/lib/wine/dsound.dll.so"
    cp "/opt/Driver/eltechs_dsound.dll.so" "/opt/wine-5.0.4/lib/wine/dsound.dll.so"
    cp "/opt/Driver/eltechs_dsound.dll.so" "/opt/wine-6.0.4/lib/wine/dsound.dll.so"
    rm "/opt/wine-5.0.4/lib/wine/dsound.dll" &>/dev/null
    rm "/opt/wine-6.0.4/lib/wine/dsound.dll" &>/dev/null
fi

eval "$@"
